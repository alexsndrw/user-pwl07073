const ubah=document.getElementById('judul');
ubah.style.color='red';
ubah.style.backgroundColor='green';
//judul1.innerHTML=‘Welcome UDINUS';

